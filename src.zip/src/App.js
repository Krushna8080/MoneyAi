import React, { useState, useEffect } from "react";
import Filters from "./components/Filters";
import Charts from "./components/Charts";
import MetricsTable from "./components/MetricsTable";
import MarketUpdates from "./components/MarketUpdates";
import axios from "axios";
import StrategyComparison from "./components/StrategyComparison";

const App = () => {
  const [portfolioData, setPortfolioData] = useState([]);
  const [allocationData, setAllocationData] = useState([]);
  const [tradesData, setTradesData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [filter, setFilter] = useState({ dateRange: "", sortBy: "" });

  // Fetch data from the backend
  useEffect(() => {
    const fetchData = async () => {
      try {
        const portfolioResponse = await axios.get("http://localhost:5000/api/portfolio");
        const allocationResponse = await axios.get("http://localhost:5000/api/allocation");
        const tradesResponse = await axios.get("http://localhost:5000/api/trades");

        setPortfolioData(portfolioResponse.data);
        setFilteredData(portfolioResponse.data);
        setAllocationData(allocationResponse.data);
        setTradesData(tradesResponse.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const applyFilters = () => {
    let updatedData = [...portfolioData];
    if (filter.dateRange) {
      updatedData = updatedData.filter((entry) => entry.date >= filter.dateRange);
    }
    if (filter.sortBy === "profitLoss") {
      updatedData.sort((a, b) => b.profitLoss - a.profitLoss);
    } else if (filter.sortBy === "value") {
      updatedData.sort((a, b) => b.value - a.value);
    }
    setFilteredData(updatedData);
  };

  return (
    <div>
      <h1>Portfolio Analytics Dashboard</h1>
      <Filters setFilter={setFilter} applyFilters={applyFilters} />
      <Charts data={filteredData} />
      <MetricsTable data={filteredData} />
      <StrategyComparison />
      <MarketUpdates trades={tradesData} allocation={allocationData} />
    </div>
  );
};

export default App;

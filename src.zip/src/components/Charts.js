import React from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";

const Charts = ({ data }) => (
  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px", marginBottom: "24px" }}>
    <div style={{ padding: "16px", backgroundColor: "#fff", border: "1px solid #ccc", borderRadius: "4px" }}>
      <h2 style={{ fontSize: "18px", fontWeight: "bold", marginBottom: "16px" }}>Portfolio Growth Over Time</h2>
      <LineChart width={400} height={300} data={data}>
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="value" stroke="#8884d8" />
      </LineChart>
    </div>

    <div style={{ padding: "16px", backgroundColor: "#fff", border: "1px solid #ccc", borderRadius: "4px" }}>
      <h2 style={{ fontSize: "18px", fontWeight: "bold", marginBottom: "16px" }}>Profit/Loss Per Strategy</h2>
      <BarChart width={400} height={300} data={data}>
        <XAxis dataKey="strategy" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="profitLoss" fill="#82ca9d" />
      </BarChart>
    </div>

    <div style={{ padding: "16px", backgroundColor: "#fff", border: "1px solid #ccc", borderRadius: "4px" }}>
      <h2 style={{ fontSize: "18px", fontWeight: "bold", marginBottom: "16px" }}>Allocation by Asset Class</h2>
      <PieChart width={400} height={300}>
        <Pie data={data} dataKey="value" nameKey="strategy" cx="50%" cy="50%" outerRadius={100}>
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={index % 2 === 0 ? "#8884d8" : "#82ca9d"} />
          ))}
        </Pie>
        <Tooltip />
      </PieChart>
    </div>
  </div>
);

export default Charts;

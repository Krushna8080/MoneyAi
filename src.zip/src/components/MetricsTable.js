import React from "react";

const MetricsTable = ({ data }) => {
  const calculateROI = (startValue, endValue) => ((endValue - startValue) / startValue) * 100;
  const calculateCAGR = (startValue, endValue, years) => (Math.pow(endValue / startValue, 1 / years) - 1) * 100;
  const calculateDrawdown = (values) => {
    const maxValue = Math.max(...values);
    const minValue = Math.min(...values);
    return ((maxValue - minValue) / maxValue) * 100;
  };

  const startValue = data[0]?.value || 0;
  const endValue = data[data.length - 1]?.value || 0;
  const years = data.length / 365; // Assuming one data point per day
  const values = data.map((entry) => entry.value);

  const roi = calculateROI(startValue, endValue);
  const cagr = calculateCAGR(startValue, endValue, years);
  const drawdown = calculateDrawdown(values);

  return (
    <div>
      <h2>Key Metrics</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Portfolio Value</th>
            <th>Profit/Loss</th>
            <th>Win Rate</th>
            <th>Strategy</th>
          </tr>
        </thead>
        <tbody>
          {data.map((entry, index) => (
            <tr key={index}>
              <td>{entry.date}</td>
              <td>${entry.value}</td>
              <td>${entry.profitLoss}</td>
              <td>{entry.winRate}%</td>
              <td>{entry.strategy}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div>
        <h3>Performance Summary</h3>
        <p>ROI: {roi.toFixed(2)}%</p>
        <p>CAGR: {cagr.toFixed(2)}%</p>
        <p>Max Drawdown: {drawdown.toFixed(2)}%</p>
      </div>
    </div>
  );
};

export default MetricsTable;

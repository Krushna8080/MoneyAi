import React, { useEffect, useState } from "react";
import axios from "axios";

const StrategyComparison = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/strategies/compare")
      .then((response) => setData(response.data))
      .catch((error) => console.error("Error fetching comparison data:", error));
  }, []);

  return (
    <div className="bg-white shadow rounded p-4">
      <h2 className="text-xl font-semibold mb-4">Strategy Comparison</h2>
      <table className="table-auto w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2 border">Strategy</th>
            <th className="p-2 border">ROI (%)</th>
            <th className="p-2 border">CAGR (%)</th>
            <th className="p-2 border">Drawdown (%)</th>
          </tr>
        </thead>
        <tbody>
          {data.map((entry, index) => (
            <tr key={index} className="text-center">
              <td className="p-2 border">{entry.strategy}</td>
              <td className="p-2 border">{entry.ROI}</td>
              <td className="p-2 border">{entry.CAGR}</td>
              <td className="p-2 border">{entry.drawdown}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StrategyComparison;

import React from "react";

const MarketUpdates = ({ trades, allocation }) => {
  return (
    <div>
      <h2>Market Updates</h2>
      <div>
        <h3>Portfolio Allocation</h3>
        <ul>
          {allocation.map((asset, index) => (
            <li key={index}>
              {asset.assetClass}: ${asset.value}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3>Recent Trades</h3>
        <ul>
          {trades.map((trade, index) => (
            <li key={index}>
              {trade.action} {trade.quantity} shares of {trade.symbol} at ${trade.price}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default MarketUpdates;
